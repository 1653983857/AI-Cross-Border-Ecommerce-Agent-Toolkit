---
description: Track and analyze insider buying/selling activity from SEC Form 4 filings
---

# Insider Trading Analysis

## ⚠️ Data Verification — Do This Before Any Analysis

Before running any analysis, always retrieve the latest market data for the ticker:

1. **Fetch current price** — use web search or ask the user for the live price, 52-week range, and market cap. Never assume a price from training data.
2. **Confirm key figures** — the Form 4 filings themselves (EDGAR, filing and transaction dates, transaction code P/S/A/M/F, 10b5-1 checkbox, shares and price), and the insider's role and remaining holdings.
3. **State your data source** — fill in the `Data & Sources` header (next section) so the origin, as-of date, retrieval path, and confidence of every figure are explicit at the top of the output.
4. **Flag stale data explicitly** — if live data is unavailable, display this warning before proceeding:

> ⚠️ **Live data unavailable.** The following analysis uses training-data estimates which may be significantly out of date. Verify all prices and metrics before making any decisions.

Never silently substitute training-data estimates for current prices. When in doubt, ask the user to paste the latest quote.

---

## 📋 Data & Sources Header — Open Every Output With It

The first thing in the output is this provenance block, filled in — never left as placeholders. It is the standard documented on the [Data & Accuracy](https://yennanliu.github.io/InvestSkill/data-and-accuracy.html) page and the first thing `result-validator` looks for:

```
Data & Sources
  As of:      <date the figures represent, e.g. 2026-06-30>
  Source:     <primary docs — SEC EDGAR 10-K/10-Q, company IR, FRED, exchange data …>
  Retrieval:  <pasted by user | web/tool retrieval | model memory>
  Confidence: <HIGH | MEDIUM | LOW>
```

- `Retrieval: model memory` must be paired with `Confidence: LOW` — memory is a placeholder until confirmed against a primary source.
- Mixed sources: list each with its own as-of date rather than blending them.
- Sources disagree on the same figure (a closing price, a deal term): prefer the primary source (SEC filing, company release, exchange data) over an aggregator, then the most recent dated one. Show both values with their sources and dates, say which you used and why, and never average them.
- Data the user pasted is reported as `pasted by user`; do not upgrade its confidence beyond what the user's own source supports.

---

## 🌐 Output Language — `--lang zh-TW`

English is the default. With `--lang zh-TW` — or when the user writes in Traditional Chinese and asks for a Chinese answer — write the whole analysis in Traditional Chinese (繁體中文, Taiwan usage), keeping it machine-checkable:

- **Translate** every heading, narrative paragraph, table header and bullet. Give each metric's English name in brackets the first time it appears — 自由現金流（Free Cash Flow, FCF） — so the reader can match it to the glossary and to English analyses.
- **Keep in English** tickers, figures and units, SEC form and item names (10-K Item 7, Form 4), the four `Data & Sources` field labels (`As of`, `Source`, `Retrieval`, `Confidence` — the Retrieval value may be written in Chinese, e.g. 使用者提供), and the Investment Signal box and JSON footer exactly as specified — field names and the BULLISH / NEUTRAL / BEARISH, HIGH / MEDIUM / LOW, BUY / HOLD / SELL, STRONG / MODERATE / WEAK values. Tools parse them.
- Title the invalidation section **論點失效條件（Thesis Invalidation）**, and close with the disclaimer in Chinese: **免責聲明：** 僅供教育用途，非投資建議。
- Use Taiwan financial terms: 殖利率、本益比、營業利益率、自由現金流、聯準會、選擇權、買權／賣權、除息日、預扣稅.

---

Comprehensive analysis of insider transaction activity to identify investment signals, patterns, and potential red flags from SEC Form 4 filings.

## Analysis Framework

### 1. Transaction Summary (Last 6-12 Months)

Provide overview of insider trading activity:

**Transaction Counts**
- Total transactions: [Number]
- Buys: [Number] ([%] of total)
- Sells: [Number] ([%] of total)
- Exercises/Awards: [Number] (non-market transactions)

**Transaction Volume**
- Total value traded: $[Amount]
- Buy volume: $[Amount]
- Sell volume: $[Amount]
- Net insider sentiment: $[Net Amount] (Buy - Sell)

**Active Period Analysis**
- Most active month: [Month]
- Clustered activity periods: [Dates]
- Quiet periods: [Dates]

### 2. Insider Sentiment Analysis

Calculate and interpret net insider sentiment:

**Net Sentiment Calculation**
```
Net Sentiment = (Buy $ - Sell $) / (Buy $ + Sell $)

Ranges:
+0.5 to +1.0  = Strongly Bullish
+0.2 to +0.5  = Moderately Bullish
-0.2 to +0.2  = Neutral
-0.5 to -0.2  = Moderately Bearish
-1.0 to -0.5  = Strongly Bearish
```

**Sentiment Context**
- Current sentiment vs. historical baseline
- Sentiment trend (improving/deteriorating)
- Significance level (number and size of transactions)
- Comparison to peer company insiders

**Reliability Factors**
- Sample size (number of insiders trading)
- Transaction size relative to holdings
- Timing relative to information events
- Consistency across multiple insiders

### 3. Significant Transactions

Highlight meaningful insider trades:

**Criteria for Significance**
- Transaction size > $1 million
- Position change > 10% of holdings
- Unusual timing (near lows/highs, before announcements)
- CEO or CFO transactions
- Multiple insiders trading in same direction within short period

**For Each Significant Transaction**

| Date | Insider | Position | Transaction | Shares | Value | % of Holdings | Price | Notes |
|------|---------|----------|-------------|--------|-------|---------------|-------|-------|
| [Date] | [Name] | [Title] | Buy/Sell | [#] | $[Amount] | [%] | $[Price] | [Context] |

**Transaction Analysis**
- **Bullish Signals**: Large insider buys, clustered buying, CEO purchases, buying near 52-week lows
- **Bearish Signals**: Large insider sells, clustered selling, executive selling before bad news
- **Neutral Signals**: Small routine sells for diversification, 10b5-1 plan executions

### 4. Insider Categories

Analyze transactions by insider role:

**Executive Officers (CEO, CFO, COO)**
- Highest signal value due to information access
- Large transactions particularly meaningful
- Sales less concerning if part of regular compensation

**Board of Directors**
- Independent directors' purchases carry strong signals
- Less frequent trading but often meaningful
- May have strategic visibility beyond operations

**Major Shareholders (>10% owners)**
- Often have board seats or strategic influence
- Large transactions can move markets
- Sales may be for portfolio rebalancing

**Other Insiders (VPs, Senior Managers)**
- Weaker signal but useful in aggregate
- Clustered activity more meaningful than individual trades
- May indicate operational knowledge

### 5. Transaction Types & SEC Forms

Interpret different transaction codes:

**Form 4 Transaction Codes**
- **P (Purchase)**: Open market buy - BULLISH SIGNAL
- **S (Sale)**: Open market sell - BEARISH SIGNAL (but often routine)
- **M (Exercise)**: Option exercise - Neutral
- **F (Tax Payment)**: Shares surrendered for taxes - Neutral
- **A (Award)**: Stock grant/award - Neutral
- **G (Gift)**: Gift transfer - Neutral
- **D (Disposition)**: Return to company - Neutral

**Form 3 vs. Form 4 vs. Form 5**
- **Form 3**: Initial statement of beneficial ownership (new insider)
- **Form 4**: Changes in ownership (filed within 2 business days)
- **Form 5**: Annual statement of changes (deferred reporting)

**10b5-1 Trading Plans**
- Pre-arranged trading plans to avoid insider trading allegations
- Marked in filings if transaction was under 10b5-1 — since April 2023, Form 4 has a dedicated checkbox and the adoption date goes in a footnote
- The SEC's 2023 amendments added a **cooling-off period** before the first trade (directors and officers: the later of 90 days after adoption or two business days after the next 10-Q/10-K, capped at 120 days; others: 30 days), limit single-trade plans to one per 12 months, and bar overlapping plans; issuers now disclose officer and director plan adoptions and terminations each quarter (10-Q/10-K, Item 408)
- Less signal value than discretionary trades
- Look for plan adoption/termination patterns — an adoption or termination shortly before material news is the informative event, and the quarterly Item 408 table is where to find it

### 6. Ownership Trends

Track changes in insider ownership percentage:

**Current Ownership Structure**
- Total insider ownership: [%]
- CEO ownership: [%]
- Top 5 insiders combined: [%]

**Ownership Trend (12 months)**
```
Quarter        Total Insider %    Change from Prior
[Qn YYYY]          [%]              [±%]
[Qn-1 YYYY]        [%]              [±%]
[Qn-2 YYYY]        [%]              [±%]
[Qn-3 YYYY]        [%]              [±%]
```

**Interpretation**
- **Increasing ownership**: Insiders accumulating = Bullish
- **Stable ownership**: Confidence maintained = Neutral to Bullish
- **Decreasing ownership**: Distribution = Bearish (but check reasons)

**Skin in the Game Assessment**
- High insider ownership (>20%): Strong alignment
- Medium ownership (10-20%): Adequate alignment
- Low ownership (<10%): Weaker alignment
- CEO ownership relative to compensation

### 7. Timing Analysis

Evaluate timing of insider transactions:

**Relative to Stock Price**
- Buying near 52-week lows: Strong bullish signal
- Buying after significant decline: Contrarian confidence
- Selling near 52-week highs: Less bearish (profit-taking)
- Selling before decline: Red flag if not disclosed later

**Relative to Information Events**
- Before earnings release
- Before major announcements (M&A, product launches)
- During blackout periods (should be restricted)
- After significant news (reaction to public information)

**Seasonal Patterns**
- Post-earnings window trading (common)
- Year-end tax-loss selling
- Quarterly option exercise cycles
- Annual equity grant patterns

**Red Flag Timing**
- Trading during supposed blackout periods
- Selling shortly before bad news announcement
- Exercising and immediately selling (vs. holding)
- Rapid succession of sells by multiple insiders

### 8. Pattern Recognition

Identify meaningful patterns in trading activity:

**Bullish Patterns**
- Clustered buying by multiple insiders within 1-2 weeks
- First-time purchases by long-tenured executives
- Buying during period of stock weakness or negative sentiment
- Insiders increasing position size significantly (>25%)
- CEO making largest purchase of tenure

**Bearish Patterns**
- Clustered selling by multiple insiders
- CEO or CFO selling large percentage of holdings
- First-time sells by insiders who previously only bought
- Selling despite stock decline (urgency to exit)
- Executive departures followed by sales

**Neutral Patterns**
- Regular quarterly option exercises and sells
- Small percentage sells for diversification (<5% of holdings)
- Tax payment share forfeitures
- Routine 10b5-1 plan executions
- Gift transfers to family trusts

### 9. Red Flags & Warning Signs

Identify concerning patterns:

**High-Severity Red Flags**
- CEO or CFO selling >50% of holdings
- Clustered selling before earnings miss or guidance cut
- Trading during blackout window
- Late Form 4 filing (>2 days) without explanation
- Pattern of selling before negative news

**Medium-Severity Red Flags**
- Increasing rate of insider selling
- Multiple executives selling simultaneously
- Selling despite recent insider buying by others
- Large sales shortly after option vesting
- Board member resignations followed by sales

**Context Matters**
- Insider selling is common and often benign
- Check for 10b5-1 plans (pre-arranged sales)
- Consider personal circumstances (divorce, estate planning)
- Look at historical patterns for that individual
- Assess whether selling is proportional to holdings

### 10. Data Sources & Research Tools

Reference the following sources for insider trading data:

**Primary Source - SEC EDGAR**
- Form 4 filings: https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&type=4&company=[TICKER]
- Form 3 filings: Initial beneficial ownership
- Form 5 filings: Annual statements
- File within 2 business days of transaction (Form 4)

**Aggregator Websites**
- **OpenInsider.com**: Free, comprehensive database with filters
  - Cluster analysis tools
  - Screeners for significant transactions
  - Historical data back 10+ years

- **SEC Form 4 Tracker**: Real-time Form 4 monitoring
- **Finviz Insider**: Basic insider data with visualizations
- **GuruFocus Insider**: Premium insider analysis

**Premium Tools**
- **Bloomberg Terminal**: Comprehensive insider data and analytics
- **FactSet**: Insider transaction database
- **S&P Capital IQ**: Detailed ownership and transaction data

**Key Data Points to Extract**
- Insider name and title
- Transaction date and filing date
- Shares bought/sold
- Price per share
- Shares owned after transaction
- Transaction code (P, S, M, etc.)
- Form 4 footnotes (10b5-1 plan indicator)

## Input Formats

### Format 1: Ticker Symbol
```
User: /insider-trading AAPL

Claude retrieves recent Form 4 data from SEC EDGAR and analyzes
```

### Format 2: Specific Time Period
```
User: /insider-trading TSLA --period 2024-Q4

Claude focuses on Q4 2024 insider transactions
```

### Format 3: Custom Data Paste
```
User: /insider-trading --data

[Paste Form 4 data table or CSV from OpenInsider/SEC]

Claude analyzes provided data
```

## Output

Provide comprehensive insider trading analysis report with:

### 1. Executive Summary
- **Overall Insider Sentiment**: Bullish / Neutral / Bearish
- **Confidence Level**: High / Medium / Low
- **Key Takeaways**: 3-5 most important findings
- **Investment Signal**: Buy / Hold / Sell indication
- **Time Period Analyzed**: [Date range]

### 2. Transaction Summary Table
```
Period: Last 6 Months
Total Transactions: [N]
Total Buy Transactions: [N] ($[Amount])
Total Sell Transactions: [N] ($[Amount])
Net Insider Activity: $[Amount]
Net Sentiment Score: [+0.XX or -0.XX]
```

### 3. Significant Transactions (Top 10)
Detailed table with context for each major transaction

### 4. Insider Category Breakdown
Analysis by executive officers, board members, and major shareholders

### 5. Ownership Trend Analysis
Current ownership % and historical trend (4 quarters)

### 6. Timing & Pattern Analysis
- Stock price context during trading periods
- Identified bullish or bearish patterns
- Seasonal or cyclical factors

### 7. Red Flags & Concerns
- List any identified warning signs
- Severity assessment
- Recommended monitoring

### 8. Comparison to Peers
Brief comparison of insider sentiment vs. industry peers (if available)

### 9. Historical Context
- How current activity compares to historical baseline
- Notable changes in behavior
- Track record of insider signals

### 10. Investment Implications
- Overall assessment and confidence level
- Key bullish factors from insider activity
- Key bearish factors or concerns
- Recommended action
- Monitoring plan for future activity

### 11. Data Sources Used
- SEC EDGAR filings referenced
- Date range of analysis
- Number of Form 4 filings reviewed

## Interpretation Guidelines

### When Insider Buying is STRONGLY Bullish
1. Multiple insiders buying in 1-2 week period
2. CEO making unusually large purchase
3. Buying after significant stock decline (>20%)
4. Insiders buying with personal cash (not option exercises)
5. First-time buyers or return to buying after long gap

### When Insider Buying is MODERATELY Bullish
1. Single insider making meaningful purchase
2. Regular accumulation pattern
3. Buying at all-time highs (conviction in further growth)
4. Board member purchases

### When Insider Selling is LESS Concerning
1. 10b5-1 pre-arranged plan sales
2. Small percentage of holdings (<5%)
3. Regular quarterly pattern
4. Diversification after large stock appreciation
5. Tax payments or estate planning

### When Insider Selling is CONCERNING
1. Clustered selling by multiple executives
2. CEO/CFO selling >25% of holdings
3. Selling despite stock decline
4. No 10b5-1 plan indicated
5. Selling shortly before negative news

### Signal Reliability Factors
- **Sample size**: More insiders trading = stronger signal
- **Magnitude**: Larger $ amounts = stronger signal
- **Timing**: Unusual timing = stronger signal
- **Context**: Contrarian trades (buying weakness) = stronger signal
- **Track record**: Historically accurate insiders = stronger signal

## Usage Examples

### Example 1: Basic Analysis
```
User: /insider-trading NVDA

Claude: Pulls the last 6 months of NVDA Form 4 filings and reports net
open-market buys vs. sells, separates 10b5-1 plan sales from discretionary
trades, flags clustered buying, and closes with the signal block.
```

### Example 2: Before Earnings
```
User: /insider-trading AAPL --period "before-earnings"

Claude: Examines trading in the 30–60 days before the most recent earnings
release and states whether anything beyond scheduled 10b5-1 sales occurred.
```

### Example 3: Red Flag Detection
```
User: /insider-trading ABC --focus red-flags

Claude: Checks each red-flag pattern above (large % of holdings sold,
clustered director exits, selling into a decline) and reports which fired,
with the filing dates that support each.
```

## Integration Notes

- Combine with /stock-eval for complete due diligence
- Use /institutional-ownership for full insider + institutional picture
- Feed analysis to /report-generator for visual charts of insider activity
- Best used monthly or after significant insider filing activity
- Particularly valuable when analyzing small-mid cap stocks (insiders have more edge)

## Thesis Invalidation

After delivering the analysis signal, specify what would reverse it:

**If signal is BULLISH — thesis breaks if:**
- 3+ insiders file Form 4 sells within a 30-day window OR CEO sells >5% of holdings
- [One or two more triggers drawn from this analysis's own drivers, each with a threshold]

**If signal is BEARISH — thesis breaks if:**
- CEO/CFO initiate new purchases >$1M within 30 days
- [One or two more triggers drawn from this analysis's own drivers, each with a threshold]

**Re-run this analysis when:**
- [ ] Next earnings release
- [ ] Price moves ±15% from current level
- [ ] 60 days have elapsed
- [ ] Material news event (acquisition, leadership change, regulatory decision)

## Standard Signal Output

All analysis concludes with this standardized block:

In the output, the box below is followed immediately by this machine-readable footer — the same values as the box, filled in (no placeholders, no comments), so tools can read the result without parsing the box:

```json
{"investskill": "1", "skill": "insider-trading", "ticker": "<TICKER, or null for a portfolio / market-wide view>", "as_of": "<YYYY-MM-DD from Data & Sources>", "signal": "<BULLISH | NEUTRAL | BEARISH>", "confidence": "<HIGH | MEDIUM | LOW>", "horizon": "<SHORT-TERM | MEDIUM-TERM | LONG-TERM>", "score": 0.0, "action": "<BUY | HOLD | SELL>", "conviction": "<STRONG | MODERATE | WEAK>", "retrieval": "<pasted by user | web/tool retrieval | model memory>", "sources": ["<each primary source, dated>"]}
```

```
╔══════════════════════════════════════════════╗
║              INVESTMENT SIGNAL               ║
╠══════════════════════════════════════════════╣
║ Signal:      BULLISH / NEUTRAL / BEARISH     ║
║ Confidence:  HIGH / MEDIUM / LOW             ║
║ Horizon:     SHORT / MEDIUM / LONG-TERM      ║
║ Score:       X.X / 10                        ║
╠══════════════════════════════════════════════╣
║ Action:      BUY / HOLD / SELL               ║
║ Conviction:  STRONG / MODERATE / WEAK        ║
╚══════════════════════════════════════════════╝
```

Score Guide: 8.0–10.0 Strongly Bullish | 6.0–7.9 Moderately Bullish | 4.0–5.9 Neutral | 2.0–3.9 Moderately Bearish | 0.0–1.9 Strongly Bearish
Confidence: HIGH (strong data, clear signals) | MEDIUM (mixed signals) | LOW (limited data, conflicting signals)
Horizon: SHORT-TERM (1 week–3 months) | MEDIUM-TERM (3 months–1 year) | LONG-TERM (1+ years)

**Disclaimer:** Educational analysis only. Not financial advice.

