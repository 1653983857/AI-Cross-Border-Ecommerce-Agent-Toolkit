---
description: Analyze US economic indicators and their impact on markets
---

# US Economics Analysis

## ⚠️ Data Verification — Do This Before Any Analysis

Before running any analysis, retrieve the latest release of every indicator you use:

1. **Fetch current readings** — use web search or ask the user for the latest value and release date of each indicator (FRED, BLS, BEA, ISM, the Fed). Never assume a reading from training data; indicators are revised and re-released on a schedule.
2. **Confirm key figures** — the policy rate, the 2s10s spread, the latest CPI/PCE, payrolls and unemployment, and PMI, each with its release date.
3. **State your data source** — fill in the `Data & Sources` header (next section) so the origin, as-of date, retrieval path, and confidence of every figure are explicit at the top of the output.
4. **Flag stale data explicitly** — if live data is unavailable, display this warning before proceeding:

> ⚠️ **Live data unavailable.** The following analysis uses training-data estimates which may be significantly out of date. Verify all prices and metrics before making any decisions.

Never silently substitute training-data estimates for current prices. When in doubt, ask the user to paste the latest release.

---

## 📋 Data & Sources Header — Open Every Output With It

The first thing in the output is this provenance block, filled in — never left as placeholders. It is the standard documented on the [Data & Accuracy](https://yennanliu.github.io/InvestSkill/data-and-accuracy.html) page and the first thing `result-validator` looks for:

```
Data & Sources
  As of:      <date the figures represent, e.g. 2026-06-30>
  Source:     <primary docs — SEC EDGAR 10-K/10-Q, company IR, FRED, exchange data …>
  Retrieval:  <pasted by user | web/tool retrieval | model memory>
  Confidence: <HIGH | MEDIUM | LOW>
```

- `Retrieval: model memory` must be paired with `Confidence: LOW` — memory is a placeholder until confirmed against a primary source.
- Mixed sources: list each with its own as-of date rather than blending them.
- Sources disagree on the same figure (a closing price, a deal term): prefer the primary source (SEC filing, company release, exchange data) over an aggregator, then the most recent dated one. Show both values with their sources and dates, say which you used and why, and never average them.
- Data the user pasted is reported as `pasted by user`; do not upgrade its confidence beyond what the user's own source supports.

---

## 🌐 Output Language — `--lang zh-TW`

English is the default. With `--lang zh-TW` — or when the user writes in Traditional Chinese and asks for a Chinese answer — write the whole analysis in Traditional Chinese (繁體中文, Taiwan usage), keeping it machine-checkable:

- **Translate** every heading, narrative paragraph, table header and bullet. Give each metric's English name in brackets the first time it appears — 自由現金流（Free Cash Flow, FCF） — so the reader can match it to the glossary and to English analyses.
- **Keep in English** tickers, figures and units, SEC form and item names (10-K Item 7, Form 4), the four `Data & Sources` field labels (`As of`, `Source`, `Retrieval`, `Confidence` — the Retrieval value may be written in Chinese, e.g. 使用者提供), and the Investment Signal box and JSON footer exactly as specified — field names and the BULLISH / NEUTRAL / BEARISH, HIGH / MEDIUM / LOW, BUY / HOLD / SELL, STRONG / MODERATE / WEAK values. Tools parse them.
- Title the invalidation section **論點失效條件（Thesis Invalidation）**, and close with the disclaimer in Chinese: **免責聲明：** 僅供教育用途，非投資建議。
- Use Taiwan financial terms: 殖利率、本益比、營業利益率、自由現金流、聯準會、選擇權、買權／賣權、除息日、預扣稅.

---

Analyze US economic conditions and their implications for investment decisions.

## Key Economic Indicators

1. **Growth Indicators**
   - GDP growth rate and components
   - Employment data (NFP, unemployment rate, jobless claims)
   - Consumer spending and retail sales
   - Manufacturing and services PMI

2. **Inflation Metrics**
   - CPI (Consumer Price Index)
   - PCE (Personal Consumption Expenditures)
   - PPI (Producer Price Index)
   - Wage growth trends

3. **Monetary Policy**
   - Federal Reserve policy stance
   - Interest rates (Fed Funds rate, Treasury yields)
   - Money supply and bank lending
   - Fed meeting minutes and forward guidance

4. **Market Sentiment**
   - Consumer confidence indices
   - Business sentiment surveys
   - Credit spreads and risk indicators
   - Market volatility (VIX)

5. **Fiscal Policy**
   - Government spending and stimulus programs
   - Tax policy changes
   - Budget deficit and debt levels

## Analysis Framework

- Identify current economic cycle phase
- Assess policy implications for different sectors
- Evaluate recession/expansion risks
- Determine impact on equity, bond, and commodity markets
- Provide sector rotation recommendations

---

## Yield Curve Analysis

### Key Spreads to Monitor

| Spread  | Definition                          | Current | 1-Year Avg | 10-Year Avg | Signal |
|---------|-------------------------------------|---------|------------|-------------|--------|
| 2s10s   | 10yr Treasury minus 2yr Treasury    |         |            |             |        |
| 3M10Y   | 10yr Treasury minus 3-Month T-Bill  |         |            |             |        |
| 5s30s   | 30yr Treasury minus 5yr Treasury    |         |            |             |        |

**3M10Y is the historically strongest recession predictor** (NY Fed model is based on this spread).

### Yield Curve Shapes

| Shape           | Description                                     | Economic Implication                                  |
|-----------------|-------------------------------------------------|-------------------------------------------------------|
| Normal (Steep)  | Long-term rates well above short-term rates     | Healthy growth expectations, bank margins expanding   |
| Flat            | Short and long-term rates near parity           | Late-cycle signal, growth slowing, Fed near peak      |
| Inverted        | Short-term rates above long-term rates          | Recession warning — markets pricing in rate cuts ahead|
| Bear Steepening | Both ends rise, long end rises faster           | Inflation concern, term premium expanding             |
| Bull Steepening | Both ends fall, short end falls faster          | Cutting cycle underway, growth relief expected        |

### Inversion Duration and Recession Lead Time

Historical precedent for 3M10Y inversion:

| Inversion Duration | Historical Recession Lead Time |
|--------------------|-------------------------------|
| < 3 months         | Unreliable signal             |
| 3–6 months         | 12–18 months typically        |
| 6–12 months        | 6–15 months typically         |
| > 12 months        | High confidence; within 12 months |

**Rule of thumb**: Yield curve uninversion (re-steepening after inversion) is often the more immediate warning — recession tends to arrive shortly after the curve re-steepens from inversion.

### Fed Rate Cycle Positioning

- **Hiking Cycle**: Fed raising rates — short end rises faster, curve flattens/inverts. Growth stocks under pressure.
- **Pause**: Fed on hold — curve stabilizes. Markets watch for pivot signals.
- **Cutting Cycle**: Fed reducing rates — short end falls faster, curve steepens. Risk-on environment, cyclicals and growth stocks benefit.

### Real Yields (TIPS) Analysis

- **Real Yield** = Nominal Treasury Yield − Breakeven Inflation Rate (derived from TIPS)
- **Rising real yields**: Tighten financial conditions. Negative for long-duration assets (growth stocks, gold, long bonds).
- **Falling real yields**: Easier financial conditions. Positive for growth stocks, gold, emerging markets, long bonds.
- **10-Year Real Yield thresholds**: Below 0% is historically accommodative; above 2% is meaningfully restrictive.
- **Breakeven inflation** (5-year, 5-year forward): Market's long-run inflation expectation. Persistently above 2.5% signals inflation concern.

---

## Credit Market Indicators

### Investment Grade (IG) Credit Spreads (OAS — Option-Adjusted Spread)

| Spread Level   | Condition  | Interpretation                                     |
|----------------|------------|----------------------------------------------------|
| < 100 bps      | Normal     | Risk appetite healthy, credit markets functioning  |
| 100–150 bps    | Caution    | Stress emerging, watch for tightening conditions   |
| > 150 bps      | Stress     | Credit markets seizing, risk-off, watch equities   |

### High Yield (HY) Credit Spreads

| Spread Level   | Condition  | Interpretation                                             |
|----------------|------------|------------------------------------------------------------|
| < 350 bps      | Normal     | Benign default environment, strong risk appetite           |
| 350–500 bps    | Caution    | Elevated risk aversion, avoid lower-quality credits        |
| > 500 bps      | Distress   | Recession/financial stress scenario, significant HY risk   |
| > 800 bps      | Crisis     | Systemic credit event risk, similar to 2008/2020 episodes  |

**Rule**: HY spreads lead equity markets by 2–4 weeks on average. Widening HY spreads while equities hold = warning signal.

### TED Spread

- **Definition**: 3-Month LIBOR (now SOFR) minus 3-Month T-Bill yield
- Measures interbank lending stress and counterparty risk appetite in the banking system
- **Normal**: < 50 bps
- **Elevated stress**: 50–100 bps
- **Crisis signal**: > 100 bps (peaked at ~450 bps during 2008 GFC)

### MOVE Index (Bond Market Volatility)

- Bond market equivalent of VIX — measures implied volatility in US Treasury options
- **Normal**: 80–100
- **Elevated**: 100–130 (policy uncertainty, high rate volatility)
- **Crisis**: > 150 (1994, 2008, 2020, 2023 banking crisis)
- High MOVE compresses equity valuations by increasing discount rates unpredictably.

### Credit as a Leading Indicator

- **IG/HY spread widening** before equity weakness is a leading warning (credit sees risk first)
- **Spread compression** while equities lag = catch-up potential, constructive signal
- **IG vs. HY divergence**: If HY widens but IG holds, idiosyncratic credit stress — watch lower-quality equities
- **Leveraged loan market**: CLO issuance and leveraged loan spreads reflect private credit conditions

---

## Global Macro Comparison

### Economic Cycle Positioning (US vs. EU vs. China)

| Economy        | Current Phase         | GDP Growth | Inflation | Policy Stance | Equity Implication          |
|----------------|-----------------------|------------|-----------|---------------|-----------------------------|
| United States  |                       |            |           |               |                             |
| Eurozone       |                       |            |           |               |                             |
| China          |                       |            |           |               |                             |
| Japan          |                       |            |           |               |                             |
| UK             |                       |            |           |               |                             |

Economic cycle phases: Early Expansion → Mid Expansion → Late Expansion → Contraction → Recovery

### PMI Comparison Across Major Economies

| Country/Region | PMI Index    | Last Reading | Trend       | Above/Below 50 |
|----------------|--------------|--------------|-------------|----------------|
| US             | ISM Mfg      |              |             |                |
| US             | ISM Services |              |             |                |
| Eurozone       | Markit Mfg   |              |             |                |
| Eurozone       | Markit Svcs  |              |             |                |
| China          | Caixin Mfg   |              |             |                |
| China          | Official PMI |              |             |                |

**Rule**: PMI above 50 = expansion; below 50 = contraction. Composite PMI below 48 for 2+ months is recessionary signal.

### Central Bank Divergence Analysis

| Central Bank | Current Rate | Last Move   | Next Expected Move | Cycle Phase |
|--------------|-------------|-------------|-------------------|-------------|
| Federal Reserve (Fed) |    |             |                   |             |
| European Central Bank (ECB) | |           |                   |             |
| Bank of Japan (BOJ) |       |             |                   |             |
| Bank of England (BOE) |     |             |                   |             |
| People's Bank of China (PBOC) | |         |                   |             |

**Divergence signals**:
- Fed tightening while ECB/BOJ easing → USD strengthens, EM currencies weaken
- Synchronized easing → Global risk-on, EM outperforms, commodities bid
- BOJ policy normalization → JPY strengthens, unwinds carry trades

### Dollar (DXY) Strength and Sector Impact

| DXY Direction | US Multinational Earnings | Commodities | Emerging Markets | Domestic US Small-Caps |
|---------------|--------------------------|-------------|-----------------|------------------------|
| Strengthening (rising DXY) | Headwind (FX translation) | Bearish | Bearish (USD-denominated debt stress) | Relative outperform |
| Weakening (falling DXY) | Tailwind | Bullish | Bullish | Relative underperform |

- **DXY above 105**: Meaningful headwind for S&P 500 multinationals (roughly 40% of S&P revenues are foreign)
- **DXY below 95**: Significant tailwind, boosts international earnings in USD terms

### Emerging Market Vulnerability Indicators

- **EM FX pressure**: Current account deficits + elevated external USD debt = vulnerable to dollar strength
- **EM Debt Stress Index**: Sovereign spread widening in EM bonds (EMBI+ spread)
- **Capital outflow risks**: Rate differential between US and EM narrows during Fed cutting cycles — can reverse
- **China contagion risk**: Property sector stress, credit impulse, and stimulus effectiveness
- **Commodity-exporting EMs**: Benefit from commodity supercycles; inversely, hurt by USD strength

---

## Recession Probability Scoring

### New York Fed Recession Model

Based on the 3M10Y yield curve spread, the NY Fed publishes a monthly recession probability for the next 12 months.

| Probability Range | Interpretation                                |
|-------------------|-----------------------------------------------|
| 0–10%             | Expansion — very low recession risk           |
| 10–25%            | Low risk — monitor indicators                 |
| 25–50%            | Elevated — caution warranted                  |
| 50–75%            | High risk — recession likely within 12 months |
| > 75%             | Near-certain — defensive positioning required |

**Current NY Fed reading**: ____%

### Conference Board Leading Economic Index (LEI)

The LEI composite combines 10 leading indicators across financial markets, labor, manufacturing, and consumer expectations.

- **Consecutive monthly declines (3+)**: Strong recession warning
- **Year-over-year decline > 4%**: Historically aligned with recessions
- **LEI component breakdown**: Manufacturing hours, building permits, consumer expectations, credit spread, yield curve, stock prices, initial jobless claims

**Current LEI trend**: Rising / Flat / Declining

### Sahm Rule

**Sahm Rule Indicator** = Current 3-month average unemployment rate minus the minimum of the 3-month average unemployment rate over the prior 12 months.

- **Threshold: ≥ 0.5 percentage points** = Real-time recession signal with high historical accuracy
- Triggered in every US recession since 1970 — and once without one so far (August 2024), so a trigger raises the odds rather than confirming a recession
- Works in real-time without revision lag that affects other indicators

**Current Sahm Indicator reading**: ____

### Custom Composite Recession Probability

Scoring model combining: Yield curve signal + LEI trend + Sahm Rule + Credit spreads + PMI momentum

| Zone           | Score Range  | Interpretation                                        |
|----------------|--------------|-------------------------------------------------------|
| Expansion      | 0–25%        | Risk-on appropriate; cyclicals, growth outperform     |
| Caution        | 25–50%       | Balanced positioning; reduce cyclical overweights     |
| High Risk      | 50–75%       | Defensive rotation; increase quality, reduce leverage |
| Near-Certain   | 75–100%      | Full defensive posture; cash, defensives, short vol   |

**Historical recession episodes and leading indicators:**

| Recession     | Yield Curve Inversion | LEI Decline | Sahm Trigger | S&P 500 Peak-to-Trough |
|---------------|-----------------------|-------------|--------------|------------------------|
| 2001 (Dot-com) | 2000                 | Yes         | Yes          | −49%                   |
| 2008 (GFC)     | 2006–2007            | Yes         | Yes          | −57%                   |
| 2020 (COVID)   | 2019                 | Yes         | Yes          | −34%                   |
| 2022–2024 (no recession declared) | 2022–2024 (longest on record) | Yes | Yes (Aug 2024) | −25% (2022 bear market) |

The 2022–2024 row is the counter-example: the curve inverted for about two years, the LEI fell, and the Sahm rule triggered in August 2024, yet no recession had been declared as of this writing. Treat the indicators as shifts in probability, not verdicts, and say so in the output.

---

## Output

Deliver concise economic assessment with:
- Current economic state summary
- Key risks and opportunities
- Sector and asset class implications
- Investment positioning recommendations

## Thesis Invalidation

After delivering the analysis signal, specify what would reverse it:

**If signal is BULLISH — thesis breaks if:**
- yield curve inverts >50bps AND leading indicators fall for 3 consecutive months
- [One or two more triggers drawn from this analysis's own drivers, each with a threshold]

**If signal is BEARISH — thesis breaks if:**
- yield curve normalizes AND PMI recovers above 52 for 2+ months
- [One or two more triggers drawn from this analysis's own drivers, each with a threshold]

**Re-run this analysis when:**
- [ ] Next earnings release
- [ ] Price moves ±15% from current level
- [ ] 60 days have elapsed
- [ ] Material news event (acquisition, leadership change, regulatory decision)

## Standard Signal Output

All analysis concludes with this standardized block:

In the output, the box below is followed immediately by this machine-readable footer — the same values as the box, filled in (no placeholders, no comments), so tools can read the result without parsing the box:

```json
{"investskill": "1", "skill": "economics-analysis", "ticker": "<TICKER, or null for a portfolio / market-wide view>", "as_of": "<YYYY-MM-DD from Data & Sources>", "signal": "<BULLISH | NEUTRAL | BEARISH>", "confidence": "<HIGH | MEDIUM | LOW>", "horizon": "<SHORT-TERM | MEDIUM-TERM | LONG-TERM>", "score": 0.0, "action": "<BUY | HOLD | SELL>", "conviction": "<STRONG | MODERATE | WEAK>", "retrieval": "<pasted by user | web/tool retrieval | model memory>", "sources": ["<each primary source, dated>"]}
```

```
╔══════════════════════════════════════════════╗
║              INVESTMENT SIGNAL               ║
╠══════════════════════════════════════════════╣
║ Signal:      BULLISH / NEUTRAL / BEARISH     ║
║ Confidence:  HIGH / MEDIUM / LOW             ║
║ Horizon:     SHORT / MEDIUM / LONG-TERM      ║
║ Score:       X.X / 10                        ║
╠══════════════════════════════════════════════╣
║ Action:      BUY / HOLD / SELL               ║
║ Conviction:  STRONG / MODERATE / WEAK        ║
╚══════════════════════════════════════════════╝
```

Score Guide: 8.0–10.0 Strongly Bullish | 6.0–7.9 Moderately Bullish | 4.0–5.9 Neutral | 2.0–3.9 Moderately Bearish | 0.0–1.9 Strongly Bearish
Confidence: HIGH (strong data, clear signals) | MEDIUM (mixed signals) | LOW (limited data, conflicting signals)
Horizon: SHORT-TERM (1 week–3 months) | MEDIUM-TERM (3 months–1 year) | LONG-TERM (1+ years)

**Disclaimer:** Educational analysis only. Not financial advice.

